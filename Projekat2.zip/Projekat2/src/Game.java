import java.util.ArrayList;

public class Game {
	private Player igrac;
	private ArrayList<Enemy> neprijatelji;
	private String log;
	
public Game() { setNeprijatelji(new ArrayList<Enemy> ()); log = ""; }

public Game(Player igrac, ArrayList<Enemy> neprijatelji, String log) {
	this.igrac = igrac;
	this.neprijatelji = neprijatelji;
	this.log = log;
}

public Player getIgrac() {
	return igrac;
}

public void setIgrac(Player igrac) {
	this.igrac = igrac;
}

public ArrayList<Enemy> getNeprijatelji() {
	return neprijatelji;
}

public void setNeprijatelji(ArrayList<Enemy> neprijatelji) {
	this.neprijatelji = neprijatelji;
}

public String getLog() {
	return log;
}

public void setLog(String log) {
	this.log = log;
}
	
public boolean checkCollision(Enemy e) {
	if (igrac.intersects(e)) return true;
	return false;
}

private void updateLog(String entry) { log += entry; }

public void decreaseHealth(Enemy e) {
	if (igrac.getHealth() < e.getDamage()) {
		System.out.print("Decrease Health: HP ne moze da padne ispod 0");
		System.out.print("Podesavamo HP na 0");
		igrac.setHealth(0); return; }	
	igrac.setHealth(igrac.getHealth() - e.getDamage());
	updateLog(	// "<BUM!> [name] (HP=...) hit by [type] (DMG=...)\n"
		"HIT: " + igrac.getIme() + "by " + e.getType()+ "for " + e.getDamage()+ " -> HP " + igrac.getHealth()+e.getDamage() + " -> " +igrac.getHealth()+
		 ")\n");
}
public void addEnemy(Enemy e) {
	if (e == null) { System.out.print("Nema neprijatelja");
		return; } neprijatelji.add(e);
	updateLog(	"Dodat neprijatlej [" + e.getType() + "] (DMG=" + e.getDamage() + ")\n");
}

public ArrayList<Enemy> findByType(String s) {
	ArrayList<Enemy> found = new ArrayList<Enemy>();
	if (s == null) { System.out.print("Nema tipa."); 
		System.out.print("Korisniku se vraca prazna lista"); return found; }
	for (Enemy e : neprijatelji)
		if (e.getType().contains(s)) found.add(e);
	if (found.size() == 0)System.out.print("_findByType: 0 found\n");
	return found;	// Ako nadje doda, ako ne nista
}

public void collidingWithPlayer() {
	for (Enemy e : neprijatelji)
		if (checkCollision(e)) neprijatelji.add(e);
	System.out.printf("_collidingWithPlayer: dodato %d neprijatelja\n");
}

public void resolveCollisions(Player p) {
	for (Enemy e : neprijatelji)
		if(checkCollision(e))
		decreaseHealth(e);
}
}
