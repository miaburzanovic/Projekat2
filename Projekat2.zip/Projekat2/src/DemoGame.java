import java.util.ArrayList;

public class DemoGame {

	public static void main(String[] args) {
		static ArrayList<Enemy> enemies = new ArrayList<Enemy>();
		static String log = "";
		Player p = new Player(5,3,5,10,"Hero",90);
		
		enemies.add(new MeleeEnemy(3,4,2,5,"Goblin",40,85));
		enemies.add(new Enemy(2,3,4,8,"Scary",20,80));
		collidingWithPlayer();
		findByType("Goblin"); // Gob -> Nece naci "Gob"
		for (Enemy e : enemies)
			checkCollision(p, e);
		p.toString();
		System.out.print(log);
	}

	}

}
