
public class Enemy extends GameObject{
	private String type;
	private int damage;
	private int health;
	
	public Enemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height);
		this.type = type;
		this.damage = damage;
		this.health = health;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		if(type!=null) {
		type=type.trim();
		this.type = type;
		}
		else {
			System.out.println("Polje tip neprijatelja ne smije biti prazno");
		}
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		if(damage>0 && damage<100)
		this.damage = damage;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		if(health>0 && health<100)
		this.health = health;
	}

	@Override
	public String toString() {
		return "Enemy [" + type + "] (" +this.getX()+ "," +this.getY()+ ") " +this.getWidth()+ "x" +this.getHeight()+ "DMG=" + damage + " HP=" + health + ".";
	}
	
	
	

}
