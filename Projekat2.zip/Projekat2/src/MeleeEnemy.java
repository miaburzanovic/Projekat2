// Nsledjuje sve iz enemy, ali da dopune ponasanje, npr u Boss da se koristi to string da bi se bidjelo da je boss
// bossenemy [type] @ (dimenzije( wxh DMG= I hp= 
// predstavlja neprijatelje koji napadaju izbliza i nanose osnovnu stetu 
// bossenemy jaci neprijatelji i nanosi duplu stetu u odnosu na vrijednost damage
// 
public class MeleeEnemy extends Enemy {
	

	public MeleeEnemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height, type, damage, health);
	}
	
	

}
