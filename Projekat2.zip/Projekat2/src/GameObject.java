
public class GameObject {
	private int x;
	private int y;
	private int width;
	private int height;
	

	public GameObject(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		if(width>0)
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		if(height>0)
		this.height = height;
	}

	@Override
	public String toString() {
		return "GameObject @ (" + x + "," + y + ") " + width + "x" + height + "]";
	}
	
	public boolean intersects(GameObject other) {
		// Prva tacka (Donje lijevo tjeme Enemy-a) { X, Y }
				if (	(this.getX() >= other.getX() && this.getX() <= (other.getX() + other.getWidth())
					&& 	(this.getY() >= other.getY() && this.getY() <= (other.getY() + other.getHeight()))))
						return true;
				// Druga tacka (Donje desno tjeme Other-a) { X + W, Y }
				else if (	((this.getX() + this.getWidth()) >= other.getX() && (this.getX() + this.getWidth()) <= (other.getX() + other.getWidth())
					&& 	(this.getY() >= other.getY() && this.getY() <= (other.getY() + other.getHeight()))))
						return true;
				// Treca tacka { X, Y + H }
				else if (	(this.getX() >= other.getX() && this.getX() <= (other.getX() + other.getWidth())
					&& 	((this.getY() + this.getHeight()) >= other.getY() && (this.getY() + this.getHeight()) <= (other.getY() + other.getHeight()))))
						return true;
				// Cetrvrta tacka { X + W, Y + H }
				else if (	((this.getX() + this.getWidth()) >= other.getX() && (this.getX() + this.getWidth()) <= (other.getX() + other.getWidth())
					&& 	((this.getY() + this.getHeight()) >= other.getY() && (this.getY() + this.getHeight()) <= (other.getY() + other.getHeight()))))
						return true;
				// Nema kolizije
				System.out.print("_checkCollision: Nema kolizije!\n");
				return false;
	}

	

}
