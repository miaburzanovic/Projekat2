
public class Player extends GameObject {
	private String ime;
	private int health;
	
	public Player(int x, int y, int width, int height, String ime, int health) {
		super(x, y, width, height);
		this.ime = ime;
		this.health = health;
	}
	
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		if(ime!=null) {
		ime=ime.trim();
		ime=ime.toLowerCase();
		this.ime = ime;
		}
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		if(health>0 && health<100)
		this.health = health;
	}

	@Override
	public String toString() {
		return "Player [" + ime + "] @ (" + this.getX() + "," +this.getY()+ ") " +this.getWidth() + "x" +this.getHeight() + " HP="  +health+ "." ;
	}
	

}
